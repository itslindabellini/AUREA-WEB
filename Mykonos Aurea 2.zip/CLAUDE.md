# AUREA Mykonos — project rules

- The navigation and footer must stay identical across ALL pages. Whenever the nav or footer changes on one page, apply the same change to every other page (desktop: Home Page Dektop, Collection Page Desktop, Product Page Desktop; mobile: Home Page Mobile, Collection Page Mobile, Product Page Mobile).
- Desktop nav is two rows: Row 1 = Home · About Us · Contact · Tracking. Row 2 = Dresses · Clothes (has dropdown) · Footwear · Jewelry · Bags. Search + cart icons sit bottom-aligned with the second nav row.
